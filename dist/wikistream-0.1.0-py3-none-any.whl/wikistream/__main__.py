import asyncio
import aiohttp
from aiosseclient import aiosseclient

async def main():
    async for event in aiosseclient('https://stream.wikimedia.org/v2/stream/recentchange'):
        print(event)

loop = asyncio.get_event_loop()
loop.run_until_complete(main())
